var Readability = require("./Readability");
var isProbablyReaderable = require("./Readability-readerable");

module.exports = {
  Readability: Readability,
  isProbablyReaderable: isProbablyReaderable
};
